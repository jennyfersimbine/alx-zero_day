My first readme.
first project with git
