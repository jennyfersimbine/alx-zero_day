directory for git project
